    $("#myDrop").click(function(){
      
      $("#myMisi").slideToggle();  //Hace que cada vez q clickees, si esta cerrado se despliega y si esta desplegado se cierra. 
      $("#myDrop").slideUp();  //cierra el otro submenu si esta abierto. 
      
    });
     
    $("#link5").click(function(){
      
      $("#drop5").slideToggle(); 
      $("#drop3").slideUp();
      
    });